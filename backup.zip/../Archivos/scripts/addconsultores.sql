﻿INSERT INTO consultor(
            idconsultor, usuario_idusuario, nombreconsultor, correoconsultor)
    VALUES (1, 1, 'consultor1','consultor1@hotmai.com');

    INSERT INTO consultor(
            idconsultor, usuario_idusuario, nombreconsultor, correoconsultor)
    VALUES (2, 2, 'consultor2','consultor2@hotmai.com');

    INSERT INTO consultor(
            idconsultor, usuario_idusuario, nombreconsultor, correoconsultor)
    VALUES (3, 3, 'consultor3','consultor3@hotmai.com');
