﻿INSERT INTO usuario(
            idusuario, login, passwd)
    VALUES (1, 'loginusuario1', 123);

INSERT INTO usuario(
            idusuario, login, passwd)
    VALUES (2, 'loginusuario2', 123);

    INSERT INTO usuario(
            idusuario, login, passwd)
    VALUES (3, 'loginusuario3', 123);