﻿INSERT INTO tipo_socio(
            codtipo_socio, nombretipo)
    VALUES (1, 'representante legal');
    
INSERT INTO tipo_socio(
            codtipo_socio, nombretipo)
    VALUES (2, 'regular');