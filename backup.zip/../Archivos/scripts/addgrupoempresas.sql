﻿INSERT INTO grupo_empresa(
            codgrupo_empresa, usuario_idusuario, nombrelargoge, nombrecortoge, 
            tothlogoge, correoge, direccionge)
    VALUES (1, 1, 'camaleon', 'cama', 
            'logocamaleon', 'camaleon@hotmail.com', 'calle siempre viva');

            INSERT INTO grupo_empresa(
            codgrupo_empresa, usuario_idusuario, nombrelargoge, nombrecortoge, 
            tothlogoge, correoge, direccionge)
    VALUES (2, 2, 'brain', 'bra', 
            'logobrain', 'brain@hotmail.com', 'calle siempre viva');

            INSERT INTO grupo_empresa(
            codgrupo_empresa, usuario_idusuario, nombrelargoge, nombrecortoge, 
            tothlogoge, correoge, direccionge)
    VALUES (3, 3, 'softwareman', 'softman', 
            'logosoft', 'softwaremann@hotmail.com', 'calle siempre viva');
